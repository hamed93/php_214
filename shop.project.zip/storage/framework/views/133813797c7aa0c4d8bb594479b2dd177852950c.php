<?php $__env->startSection('content'); ?>
    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
        <div class="page-header head-section">
            <h2>همه نظرات</h2>
        </div>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                <tr>
                    <th>نام کاربر</th>
                    <th>مقدار پرداختی</th>
                    <th>نوع پرداخت</th>
                    <th>تنظیمات</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($payment->user->name); ?></td>
                        <td><?php echo e($payment->price); ?></td>
                        <?php if($payment->course_id == 'vip'): ?>
                            <td>بابت عضویت ویژه</td>
                        <?php else: ?>
                            <td><?php echo e($payment->course->title); ?></td>
                        <?php endif; ?>
                        <td>
                            <div style="display: flex">
                                <form action="<?php echo e(route('payments.destroy'  , ['id' => $payment->id])); ?>" method="post">
                                    <?php echo e(method_field('delete')); ?>

                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" class="btn btn-xs btn-danger">حذف</button>
                                </form>
                                <form style="margin-right: 5px" action="<?php echo e(route('payments.update'  , ['id' => $payment->id])); ?>" method="post">
                                    <?php echo e(method_field('patch')); ?>

                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" class="btn btn-xs btn-success">تایید</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div style="text-align: center">
            <?php echo $payments->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>