<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    

    <title>وب سایت فروشگاه  اینترنتی</title>

    <!-- Bootstrap core CSS -->
    

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    

  <link rel="stylesheet"  href=" <?php echo e(asset('css/admin.css')); ?>" >
  </head>

  <body>
     
     <?php echo $__env->make('admin.section.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
     
     <?php echo $__env->yieldContent('content'); ?>;
     
     <?php echo $__env->make('admin.section.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
  
    </body>
</html>
