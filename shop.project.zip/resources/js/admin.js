window.$ = window.jQuery  =require("./files/jquery.min.js");
require("./files/bootstrap.min.js");

