<?php

use Illuminate\Support\Carbon;

function user() {
    return auth()->user();
}